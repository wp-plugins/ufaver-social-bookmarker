=== uFaver Social Bookmarking Widget ===
Contributors: uFaver
Donate Link: www.cashnoob.com
Tags: bookmarking, social, social bookmarking, bookmark, bookmarks, sharing, share, saving, save, Post, posts, page, pages, images, image, admin, statistics, stats, links, plugin, widget, e-mail, email, seo, button, delicious, google, digg, reddit, facebook, myspace, twitter, stumbleupon, technorati, wpmu, ufave, favorites, vouchers, amazon, hosting, domain names, free
Version: 1.0
Tested up to: WP 2.7
Stable tag: 1.0

----------------------------------------------------------------------
== Description ==

The uFaver button makes easier for your users to bookmark and share your articles with other people. With simple 1 click - install, it�s powerfull enough to spread your content across the web.


== Installation ==

1. Upload 'ufave' directory ( including files and folders ) to your '/wp-content/plugins/' directory

2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

Q: Can i choose a different button to display?

A: Currently no! The widget has only 1 button ( the stock button ) because it is the first version of the script. In the future we hope to develop more the widget and have more buttons.


Q: How much i have to pay for this service?

A: NOTHING !!! Even ads are not allowed.

Q: The widget look horible on my blog. What should i do?

A: Just write an email at ufave@ufave.us with your problem, and we will make all the posible to resolve it. FREE of charge !!


== Screenshots ==

The .zip package has 2 screenshots of the widget


----------------------------------------------------------------------


 Thank you for using our plugin.
 More info & updates at www.credits4gifts.com
 Any other problem, mail to mail@credits4gifts.com